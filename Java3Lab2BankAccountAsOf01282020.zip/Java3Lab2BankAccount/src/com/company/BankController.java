package com.company;

import java.util.Scanner;

public class BankController {
    BankModel model;
    BankView view;
    Scanner input;
    public BankController(BankModel model, BankView view){
        this.model = model;
        this.view = view;
        input = new Scanner(System.in);
    }

    public void inputLoop() {
        // HERE FOR REFERENCE == NOT REQUIRED TO IMPLEMENT
        // tell view to display menu for loading new or old model => yes/no
        //view.displayLoadMenu():
        //int res = scanner.nextInt();
        // tell model to load new or old model using previous answer => model
        //model = model.loadBankModel(res);


        // tell view to display actions menu
        while (true) {
            ;

            view.displayMenu();
            int res = input.nextInt();
            // based on response call model then view w/ info
            // great spot for switch/case (hint hint)
            Integer acctNum = 0;
            String name = null;


            switch (res) {

                case 1:
                    System.out.println("Please enter a first name for the new account you wish to create: ");
                    name = input.next();
                    acctNum = model.addAcct(name);
                    break;

                case 2:
                    System.out.println("Enter the first name of the account you would like to display:");
                    name = input.next();
                    System.out.println(name);
                    break;

                case 3:
                    System.out.println("Enter the first name of the account you would like to delete: ");
                    name = input.next();
                    System.out.println(name);
                    break;
                case 4:
                    System.out.println("Enter the first name of the account you would like to withdraw money from: ");
                    name = input.next();
                    System.out.println(name);
                    break;
                case 5:
                    System.out.println("Enter the first name of the account you would like to deposit money into: ");
                    name = input.next();
                    System.out.println(name);
                    break;
                case 6:
                    System.out.println("You are now exiting the Teller Menu.  Goodbye");
                    model.saveBankModel();
                    return;
            }
            view.displayAcct(acctNum, name);

        }

    }
}
