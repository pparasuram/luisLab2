package com.company;

import java.math.BigDecimal;

public class BankView {
        public BankView (){
        }

        //Remove this later or it will always print 0

    public void displayAcct(Integer id, String name){
            displayAcct(id, name, new BigDecimal(0));
    }

    public void displayAcct(Integer id, String name, BigDecimal balance){
            System.out.println("==================");
            System.out.println("Name: " + name);
            System.out.println("Balance: " + balance);
            System.out.println("ID: " + id);
            System.out.println("==================");
        }

        public void displayMenu(){
            System.out.println("Please enter a choice from the below");
            System.out.println("==================");
            System.out.println("1. Add New Account");
            System.out.println("2. Display account");
            System.out.println("3. Delete An Account");
            System.out.println("4. Withdraw from an Account");
            System.out.println("5. Deposit to An account");
            System.out.println("6. Exit Teller Menu");
            System.out.println("==================");
        }

}
