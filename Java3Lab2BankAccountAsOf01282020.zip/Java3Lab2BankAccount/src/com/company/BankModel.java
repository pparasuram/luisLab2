package com.company;

import java.io.*;
import java.util.HashMap;


public class BankModel implements Serializable {
    HashMap<Integer, Account> data;
    Integer nextAcctId;

    public BankModel() {
        data = new HashMap<Integer, Account>();
        nextAcctId = 1;
    }

    public static BankModel loadBankModel() {
        BankModel model = new BankModel();

        try {
            FileInputStream fis = new FileInputStream("BankInfo.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            model = (BankModel) ois.readObject();
            ois.close();
            fis.close();
            return model;


        } catch (IOException ioe) {

            return model;

        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
            c.printStackTrace();
            return model;

        }
    }

    public void saveBankModel() {


        try {
            FileOutputStream fos =
                    new FileOutputStream("BankInfo.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            oos.close();
            fos.close();
            System.out.printf("Serialized HashMap data is saved in hashmap.ser");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }


    public String getAcct(Integer id) {
        Account a = data.get(id);
        return a.name;
        //return data.get(id).name;
    }

    public Integer addAcct(String name) {
        Integer acctNum = this.nextAcctId;
        try {
            Account a = new Account();
            a.name = name;
            a.acctNum = acctNum;
            data.put(acctNum, a);
            this.nextAcctId++;
        } catch (Exception e) {
            return -1;
        }
        return acctNum;
    }

}
